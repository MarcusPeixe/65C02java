# 65C02java

== EMULATOR COMPLETED ==
Currently it was only tested with Klaus Dormann's test suite, and it passed 

== GRAPHICAL USER INTERFACE (WIP) ==
Currently developing the GUI

== ASSEMBLER (WIP) ==
Creating a simple assembler for this emulator
